/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package m.console;
import java.util.Scanner;
/**
 *
 * @author Student
 */
public class Console {






    // =========================
    // INTERFACE
    // =========================
    interface IConsole {

        String getConsoleType();

        String getStore();

        int getTotalSales();
    }

    // =========================
    // ABSTRACT CLASS
    // =========================
    static abstract class ConsoleSalesBase implements IConsole {

        private String consoleType;
        private String store;
        private int totalSales;

        // Constructor
        public ConsoleSalesBase(String consoleType, String store, int totalSales) {
            this.consoleType = consoleType;
            this.store = store;
            this.totalSales = totalSales;
        }

        // Get console type
        @Override
        public String getConsoleType() {
            return consoleType;
        }

        // Get store
        @Override
        public String getStore() {
            return store;
        }

        // Get total sales
        @Override
        public int getTotalSales() {
            return totalSales;
        }
    }

    // =========================
    // CONCRETE CLASS
    // =========================
    static class ConsoleSales extends ConsoleSalesBase {

        public ConsoleSales(String consoleType, String store, int totalSales) {
            super(consoleType, store, totalSales);
        }

        // Print report
        public void printReport() {
            System.out.println();
            System.out.println("CONSOLE SALES REPORT");
            System.out.println("---------------------");
            System.out.println("CONSOLE TYPE: " + getConsoleType());
            System.out.println("STORE: " + getStore());
            System.out.println("TOTAL SALES: " + getTotalSales());
            System.out.println("---------------------");
        }
    }

    // =========================
    // MAIN METHOD
    // =========================
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("Select the console type");
        System.out.println("1) PS5");
        System.out.println("2) XBOX");
        System.out.println("3) SWITCH");
        System.out.print("Enter your choice: ");

        int choice = input.nextInt();
        input.nextLine();

        String consoleType;

        switch (choice) {
            case 1:
                consoleType = "PS5";
                break;

            case 2:
                consoleType = "XBOX";
                break;

            case 3:
                consoleType = "SWITCH";
                break;

            default:
                System.out.println("Invalid choice.");
                input.close();
                return;
        }

        System.out.println();

        System.out.print("Enter the store name: ");
        String store = input.nextLine();

        System.out.print("Enter the total sales for "
                + consoleType + " consoles: ");
        int totalSales = input.nextInt();

        // Create object
        ConsoleSales console = new ConsoleSales(
                consoleType,
                store,
                totalSales
        );

        // Display report
        console.printReport();

        input.close();
    }
}
    

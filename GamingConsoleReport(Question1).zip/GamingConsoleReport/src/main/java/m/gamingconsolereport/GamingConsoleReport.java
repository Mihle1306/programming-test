/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package m.gamingconsolereport;

/**
 *
 * @author Student
 */
public class GamingConsoleReport {

    public static void main(String[] args) {

        // 1D array containing the city names
        String[] cities = {
            "CAPE TOWN",
            "PORT ELIZABETH",
            "PRETORIA"
        };

        // 1D array containing console names
        String[] consoles = {
            "PS5",
            "XBOX",
            "SWITCH"
        };

        // 2D array containing sales
        int[][] sales = {
            {1000, 2000, 3000},
            {2000, 3000, 4000},
            {1500, 1100, 1200}
        };

        System.out.println("==============================================");
        System.out.println("           GAMING CONSOLE REPORT");
        System.out.println("==============================================");

        System.out.printf("%-20s %-10s %-10s %-10s%n",
                "", "PS5", "XBOX", "SWITCH");

        // Display the sales
        for (int i = 0; i < sales.length; i++) {

            System.out.printf("%-20s", cities[i]);

            for (int j = 0; j < sales[i].length; j++) {
                System.out.printf("%-10d", sales[i][j]);
            }

            System.out.println();
        }

        System.out.println();
        System.out.println("----------------------------------------------");
        System.out.println("CONSOLE SALES TOTALS FOR EACH CITY");
        System.out.println("----------------------------------------------");

        int highestSales = 0;
        String highestCity = "";

        // Calculate total sales for each city
        for (int i = 0; i < sales.length; i++) {

            int total = 0;

            for (int j = 0; j < sales[i].length; j++) {
                total += sales[i][j];
            }

            System.out.printf("%-20s %d%n", cities[i], total);

            // Find city with highest sales
            if (total > highestSales) {
                highestSales = total;
                highestCity = cities[i];
            }
        }

        System.out.println();
        System.out.println("----------------------------------------------");
        System.out.println("CITY WITH THE MOST SALES: " + highestCity);
        System.out.println("TOTAL SALES: " + highestSales);
        System.out.println("----------------------------------------------");
    }
}


   